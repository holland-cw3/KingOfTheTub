using System.Diagnostics;
using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerController : MonoBehaviour
{
    //Private Variables
    [SerializeField] Rigidbody2D playerRb;
    [SerializeField] LayerMask groundLayer, beakLayer;
    [SerializeField] Transform feet, beak;


    public float speed = 10f;
    public float jumpForce = 15f;
    public float gravityModifier;
    private Vector2 movementInput;

    public Animator animator;

    private float jumpCooldown;
    private bool facingRight;

    private bool canFly = true;
    private float flyCooldown = .6f; // The duration of the cooldown in seconds
    private float lastFlyTime = 0f;




    // Start is called before the first frame update
    void Start()
    {
        facingRight = true;
        playerRb = GetComponent<Rigidbody2D>();
        Physics2D.gravity *= gravityModifier;
    }


    public void Update()
    {
        //onMove is setting these values, Update is just ensuring continuous movement.
        float horizontalInput = movementInput.x;
        float verticalInput = movementInput.y;

        //for player animations
        animator.SetFloat("Speed", Mathf.Abs(horizontalInput));


        if (Time.time - lastFlyTime >= flyCooldown)
        {
            canFly = true;
        }
        // If the vertical input is significant, Jump
        if (verticalInput > 0.5f && canFly)
        {
            Fly();
            canFly = false;
            lastFlyTime = Time.time;

        }

        //CheckGrounded();
        //CheckBeakCollision();


        // Right or left movement input
        if (horizontalInput > 0.5f || horizontalInput < -0.5f) 
            moveLeftOrRight(horizontalInput);
    }

    public void onMove(InputAction.CallbackContext ctx)
    {
        movementInput = ctx.ReadValue<Vector2>();
    }

    void moveLeftOrRight(float horizInput)
    {
        float movement = horizInput * speed * Time.deltaTime;
        transform.Translate(new Vector3(movement, 0f, 0f));

        
        if (horizInput > 0.5f && !facingRight)
        {
            Flip();
            facingRight = true;
        }
        else if (horizInput < -0.5f && facingRight)
        {
            Flip();
            facingRight = false;
        }
    }

    void Fly()
    {
        playerRb.velocity = new Vector2(playerRb.velocity.x, jumpForce);
    }

    /*void CheckGrounded()
    {
        if (Physics2D.OverlapCircle(feet.position, .2f, groundLayer))
        {
            isGrounded = true;

            jumpCount = 0;
            jumpCooldown = Time.time + 0.2f;
        }
        
        else if (Time.time < jumpCooldown && jumpCount < extraJumps)
        {
            isGrounded = true;
        }
        else
        {
            isGrounded = false;
        }
        UnityEngine.Debug.Log(isGrounded);
    }*/

    void Flip()
    {
        facingRight = !facingRight;
        Vector3 theScale = transform.localScale;
        theScale.x *= -1;
        transform.localScale = theScale;
    }

    void CheckBeakCollision()
    {
        if (Physics2D.OverlapCircle(beak.position, .2f, beakLayer))
        {
            //Just testing if it works. It does so whatever we want to do with the beak can be here
            UnityEngine.Debug.Log("Destroy");
        }
    }
}

