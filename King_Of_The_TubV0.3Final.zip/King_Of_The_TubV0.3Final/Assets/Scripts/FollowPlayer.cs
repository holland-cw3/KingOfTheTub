using System.Collections;
using System.Collections.Generic;
using Unity.VisualScripting;
using UnityEngine;
using static UnityEngine.GraphicsBuffer;

public class FollowPlayer : MonoBehaviour
{
    public GameObject player;
    private float screenLengthX = 19.85f;
    private float numScreensX = 1;
    private Vector3 offset = new Vector3(9.08f, 2, -10);
    private Vector3 initalPos;
    private Vector3 newPos;


    // Start is called before the first frame update
    void Start()
    {
        initalPos = new Vector3(player.transform.position.x, player.transform.position.y, 0);
    }

    // Update is called once per frame
    void Update()
    {
        if (player.transform.position.x > initalPos.x + screenLengthX * numScreensX)
        {
            transform.position = player.transform.position + offset;
            newPos = new Vector3(player.transform.position.x, transform.position.y, 0);
            numScreensX += 1;
        }
        if (player.transform.position.x < newPos.x && numScreensX != 1)
        {
            numScreensX -= 1;
            newPos = new Vector3(newPos.x - screenLengthX + offset.x, transform.position.y, transform.position.z);
            transform.position = newPos;
        }
    }
}
