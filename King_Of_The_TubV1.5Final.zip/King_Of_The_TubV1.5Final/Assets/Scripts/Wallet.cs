using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

public class Wallet : MonoBehaviour
{
    public TMP_Text coinText;
    public static int walletCoins;
    public int amount;

   
    // Start is called before the first frame update
    void Start()
    {
        coinText.text = "Coins: " + walletCoins.ToString();
    }

    public void DecreaseCoins(int amount)
    {
        if (!(walletCoins - amount < 0))
        {
            walletCoins -= amount;
            coinText.text = "Coins: " + walletCoins.ToString();
        }

    }

}
