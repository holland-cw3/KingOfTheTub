using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    //Private Variables
    [SerializeField] Rigidbody2D playerRb;
    [SerializeField] LayerMask groundLayer;
    [SerializeField] Transform feet;

    public float speed = 2f;
    public float jumpForce = 15f;
    public float gravityModifier;
    public int extraJumps = 1;

    private int jumpCount = 0;
    private bool isGrounded;
    private float horizontalInput;
    private float jumpCooldown;
    private bool facingRight;



    // Start is called before the first frame update
    void Start()
    {
        facingRight = true;
        playerRb = GetComponent<Rigidbody2D>();
        Physics2D.gravity *= gravityModifier;
    }

    // Update is called once per frame
    void Update()
    {

        if (Input.GetKeyDown(KeyCode.Space))
        {
            Jump();
        }

        if (Input.GetAxisRaw("Horizontal") > 0.5f || Input.GetAxisRaw("Horizontal") < -0.5f)
        {
            transform.Translate(new Vector3(Input.GetAxisRaw("Horizontal") * speed * Time.deltaTime, 0f, 0f));
            if (Input.GetAxisRaw("Horizontal") > 0.5f && !facingRight)
            {
                Flip();
                facingRight = true;
            }
            else if (Input.GetAxisRaw("Horizontal") < 0.5f && facingRight)
            {
                Flip();
                facingRight = false;
            }

            CheckGrounded();
        }
    }



        void Jump()
        {
            if (isGrounded || jumpCount < extraJumps)
            {
                playerRb.velocity = new Vector2(playerRb.velocity.x, jumpForce);
                jumpCount++;
            }

        }

        void CheckGrounded()
        {
            if (Physics2D.OverlapCircle(feet.position, 0.5f, groundLayer))
            {
                isGrounded = true;
                jumpCount = 0;
                jumpCooldown = Time.time + 0.2f;
            }
            else if (Time.time < jumpCooldown)
            {
                isGrounded = true;
            }
            else
            {
                isGrounded = false;
            }
        }

        void Flip()
        {
            facingRight = !facingRight;
            Vector3 theScale = transform.localScale;
            theScale.x *= -1;
            transform.localScale = theScale;
        }
    }

