using System.Collections;
using UnityEngine;

public class Laser : MonoBehaviour
{
    private Transform spriteTransform;

    void Start()
    {
        spriteTransform = GetComponent<Transform>();
        StartCoroutine(ScaleCoroutine());
    }

    IEnumerator ScaleCoroutine()
    {
        while (true)
        {
            spriteTransform.localScale = new Vector3(spriteTransform.localScale.x, spriteTransform.localScale.y + 10f, spriteTransform.localScale.z); ;

            yield return new WaitForSeconds(3.0f);

            spriteTransform.localScale = new Vector3(spriteTransform.localScale.x, 0, spriteTransform.localScale.z); ;

            yield return new WaitForSeconds(3.0f);
        }
    }
}
