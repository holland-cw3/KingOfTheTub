using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    //Private Variables
    [SerializeField] Rigidbody2D playerRb;
    [SerializeField] LayerMask groundLayer;
    [SerializeField] Transform feet, Beak;


    public float speed = 2f;
    public float jumpForce = 15f;
    public float gravityModifier;
    public int extraJumps = 1;

    public Animator animator;

    private int jumpCount = 0;
    public bool isGrounded;
    private float horizontalInput;
    private float jumpCooldown;
    private bool facingRight;



    // Start is called before the first frame update
    void Start()
    {
        facingRight = true;
        isGrounded = true;
        playerRb = GetComponent<Rigidbody2D>();
        Physics2D.gravity *= gravityModifier;
    }

    // Update is called once per frame
    void Update()
    {
        animator.SetFloat("Speed", Mathf.Abs(Input.GetAxisRaw("Horizontal")));


        if (Input.GetKeyDown(KeyCode.Space))
        {
            Jump();
        }

        CheckGrounded();

        if (Input.GetAxisRaw("Horizontal") > 0.5f || Input.GetAxisRaw("Horizontal") < -0.5f)
        {
            transform.Translate(new Vector3(Input.GetAxisRaw("Horizontal") * speed * Time.deltaTime, 0f, 0f));


            if (Input.GetAxisRaw("Horizontal") > 0.5f && !facingRight)
            {
                Flip();
                facingRight = true;
            }
            else if (Input.GetAxisRaw("Horizontal") < 0.5f && facingRight)
            {
                Flip();
                facingRight = false;
            }
        }



    }



    void Jump()
    {
        if (isGrounded || jumpCount < extraJumps)
        {
            jumpCount++;
            playerRb.velocity = new Vector2(playerRb.velocity.x, jumpForce);
        }

    }

    void CheckGrounded()
    {
        if (Physics2D.OverlapCircle(feet.position, .2f, groundLayer))
        {
            isGrounded = true;

            jumpCount = 0;
            jumpCooldown = Time.time + 0.2f;
        }
        
        else if (Time.time < jumpCooldown && jumpCount < extraJumps)
        {
            isGrounded = true;
        }
        else
        {
            isGrounded = false;
        }
        UnityEngine.Debug.Log(isGrounded);
    }

    void Flip()
    {
        facingRight = !facingRight;
        Vector3 theScale = transform.localScale;
        theScale.x *= -1;
        transform.localScale = theScale;
    }
}

