using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Flicker : MonoBehaviour
{
    public GameObject img;
    void Start()
    {
        // active
        img.gameObject.SetActive(true);

        //deactive
       // img.gameObject.SetActive(false);
    }
    void update()
    {
        Debug.Log("he");

        if (img.gameObject.activeSelf == true){
            img.gameObject.SetActive(false);
        }
        else
        {
            img.gameObject.SetActive(true);
        }
    }
}
