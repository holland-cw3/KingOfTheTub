using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    //Private Variables
    private Rigidbody2D playerRb;
    private bool isGrounded = false;
    private bool doubleJumpReady = false;
    private float horizontalInput;
    public float speed = 10.0f;
    public float gravityModifier;
    public float jumpForce = 700f;
    public float doubleJumpForce = 350f;
    public float delay = 0.5f;
    


    //private float verticalInput;
    // Start is called before the first frame update
    void Start()
    {
        playerRb = GetComponent<Rigidbody2D>();
        Physics2D.gravity *= gravityModifier;
    }

    // Update is called once per frame
    void Update()
    {
        // Moves the player left and right
        horizontalInput = Input.GetAxis("Horizontal");
        transform.Translate(Vector2.right * Time.deltaTime * speed * horizontalInput);

        //Little issue with the double jump being irregular when spamming spacebar and taking time clicking spacebar
        if (Input.GetKeyDown(KeyCode.Space))
        {
            if (isGrounded)
            {
                playerRb.AddForce(new Vector2(0f, jumpForce), ForceMode2D.Impulse);
                doubleJumpReady = true;
                isGrounded = false;
            }
            else if (doubleJumpReady)
            {
                playerRb.AddForce(new Vector2(0f, doubleJumpForce), ForceMode2D.Impulse);
                doubleJumpReady = false;
            }
        }
    }
    void OnCollisionEnter2D(Collision2D collision)
    {
        if (collision.gameObject.CompareTag("Ground"))
        {
            Invoke("SetGrounded", delay);
        }
    }

    void SetGrounded()
    {
        isGrounded = true;
    }
}
